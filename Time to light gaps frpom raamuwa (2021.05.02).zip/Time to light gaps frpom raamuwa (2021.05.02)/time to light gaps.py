# Written BY Dimuthu Praboda(Hibutta)..........
#කතෘ හිමිකම් සුරකින්න.

import math
#x=float(input("Number"))
#print(math.sqrt(x))



print("____________________Time to light gaps_________________________\n")

t0 = float(input("t0 :- "))
#v = float(input("v :- "))
#c = float(input("c :- "))
c = 299792458
c=float(c)
v=c*0.9
v=float(v)


t = t0/math.sqrt(1-((v*v)/(c*c)))

print(t)
print("\n\n________________end_________________\n\n")


#print(v*v)
#print(c*c)
#print((v*v)/(c*c))



# Written BY Dimuthu Praboda(Hibutta)..........
#කතෘ හිමිකම් සුරකින්න.